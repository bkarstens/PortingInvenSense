var a00012 =
[
    [ "accel_cfg_0_reg", "a00012.html#a07d0b5ff6daa89a734052c4a3206ea26", null ],
    [ "bank_sel_reg", "a00012.html#a0086eeb08c2ba0a7df357270f0aed8c5", null ],
    [ "gyro_cfg_0_reg", "a00012.html#aa1b329fcb91ea58835aa11d9974bf8a5", null ],
    [ "intf_cfg_1_reg", "a00012.html#a049893a073168c46f02848c569570f9c", null ],
    [ "pwr_mngt_0_reg", "a00012.html#a4274df728587f6002da3e4eb977629e5", null ],
    [ "tmst_cfg_reg", "a00012.html#ada4aaa9d393c2ce51851cea077ff57b8", null ]
];