var a00025 =
[
    [ "Icm426xxExtFunc.h", "a00018.html", null ],
    [ "inv_icm426xx_get_time_us", "a00025.html#ga9cd3a1ad40d57b104d59b5ad1b30308e", null ],
    [ "inv_icm426xx_sleep_us", "a00025.html#ga7503f8097a1c53dac45aeb822dfbb0f8", null ]
];