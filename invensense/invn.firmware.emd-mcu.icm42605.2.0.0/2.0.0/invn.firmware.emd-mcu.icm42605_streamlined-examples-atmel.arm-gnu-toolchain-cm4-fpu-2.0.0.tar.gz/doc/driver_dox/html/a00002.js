var a00002 =
[
    [ "acc_ln_bw", "a00002.html#a0c7d134229f97f1ae2f44b98b63c158a", null ],
    [ "acc_lp_avg", "a00002.html#a590b7960b0c21125860be16f557ad4a1", null ],
    [ "accel_start_time_us", "a00002.html#abc34c3ac9714766cf7fbe00a7d3eaef9", null ],
    [ "dmp_is_on", "a00002.html#ac129fc832ca9841014c4940d380c7cf0", null ],
    [ "endianess_data", "a00002.html#ac6ebd4a1e7cc526d89989e1c61f4d55e", null ],
    [ "fifo_data", "a00002.html#a371a64780ed95460a930f218c8d5d5b6", null ],
    [ "fifo_highres_enabled", "a00002.html#ab7906a2bebfa265cf41c5c306c49ab6a", null ],
    [ "fifo_is_used", "a00002.html#aa97fd09572c498b7e4584822bbb1aef1", null ],
    [ "gyr_ln_bw", "a00002.html#a32790b71eded20d5ecbe0fe9c857e1c7", null ],
    [ "gyro_power_off_tmst", "a00002.html#aab6c12386f400714d6177a749f54ab40", null ],
    [ "gyro_st_bias", "a00002.html#ad193086dcd63b56459ab51735249617e", null ],
    [ "gyro_start_time_us", "a00002.html#a732380c3504751b97651c0eb96f8a042", null ],
    [ "reserved", "a00002.html#a35de734d6638901060bad7a6d3c6c887", null ],
    [ "sensor_event_cb", "a00002.html#ab510d48d30cb92123c4de6c849eafaff", null ],
    [ "st_result", "a00002.html#aef28bfd8c914080b543d8f79075ebefd", null ],
    [ "tmst_to_reg_en_cnt", "a00002.html#aa6b42665009853c33f4aad8be2c48960", null ],
    [ "transport", "a00002.html#a5fb6f175a9fdc8f9f7f633474cf6179d", null ],
    [ "wom_enable", "a00002.html#ad81c915123ef3de934b4cc7d83526b34", null ],
    [ "wom_smd_mask", "a00002.html#a19db3071e2550db94e97be3b69102345", null ]
];