var searchData=
[
  ['dmp_5fis_5fon',['dmp_is_on',['../a00002.html#ac129fc832ca9841014c4940d380c7cf0',1,'inv_icm426xx']]],
  ['double_5ftap_5ftiming',['double_tap_timing',['../a00008.html#abd48fc5af17c55ba4a37127f33cd6631',1,'inv_icm426xx_tap_data']]]
];
