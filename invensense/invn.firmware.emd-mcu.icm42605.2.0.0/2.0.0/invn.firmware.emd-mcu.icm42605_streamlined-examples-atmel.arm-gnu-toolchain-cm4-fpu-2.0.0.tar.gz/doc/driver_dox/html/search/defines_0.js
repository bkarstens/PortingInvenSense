var searchData=
[
  ['bit_5fapex_5fdata4_5ftap_5fnum_5fpos',['BIT_APEX_DATA4_TAP_NUM_POS',['../a00013.html#ab3219f63f67db7061e8643fa3fed0995',1,'Icm426xxDefs.h']]]
];
