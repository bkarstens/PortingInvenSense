var indexSectionsWithContent =
{
  0: "abdefgilmprstw",
  1: "fir",
  2: "i",
  3: "i",
  4: "abdefgilmprstw",
  5: "i",
  6: "i",
  7: "i",
  8: "b",
  9: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules"
};

