var searchData=
[
  ['recover_5fregs',['recover_regs',['../a00011.html',1,'']]],
  ['register_5fcache',['register_cache',['../a00012.html',1,'inv_icm426xx_transport']]]
];
