var searchData=
[
  ['max_5fpeak_5ftol',['max_peak_tol',['../a00009.html#a0396dd628fece1cfc3f0767acebe82b3',1,'inv_icm426xx_tap_parameters_t']]],
  ['min_5fjerk_5fthr',['min_jerk_thr',['../a00009.html#ad5a5aef9818f530f70446a045beecb5b',1,'inv_icm426xx_tap_parameters_t']]]
];
