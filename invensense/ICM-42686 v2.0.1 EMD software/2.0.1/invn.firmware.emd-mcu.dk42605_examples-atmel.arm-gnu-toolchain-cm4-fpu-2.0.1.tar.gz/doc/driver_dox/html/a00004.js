var a00004 =
[
    [ "activity_class", "a00004.html#a7c1ca797a213de8358b7dc63c00a67bd", null ],
    [ "step_cadence", "a00004.html#ae54efd252e767b3c9fb8f460833a4aa8", null ],
    [ "step_cnt", "a00004.html#a72e853bcaba8ab19b2153ffec672b997", null ]
];