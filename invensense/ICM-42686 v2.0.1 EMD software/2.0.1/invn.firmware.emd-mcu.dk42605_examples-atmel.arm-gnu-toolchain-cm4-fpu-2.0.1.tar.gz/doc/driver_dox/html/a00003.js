var a00003 =
[
    [ "low_energy_amp_th", "a00003.html#a19c8f2cc5db9e96c32a851b51c811e0e", null ],
    [ "pedo_amp_th", "a00003.html#a87ba0c04a84d0dfff13781a698684616", null ],
    [ "pedo_hi_enrgy_th", "a00003.html#a0cf1b02a112d6c4752f9566fabafa280", null ],
    [ "pedo_sb_timer_th", "a00003.html#a5728ff6182020d1a7037cf146767f108", null ],
    [ "pedo_step_cnt_th", "a00003.html#aec5e489da52a1c4c875c6ced64f3e4a1", null ],
    [ "pedo_step_det_th", "a00003.html#a4221eecaf0e3a99094d42c855ef64512", null ],
    [ "power_save", "a00003.html#a978f105c2fa2a6b317ecda930b74d0a5", null ],
    [ "power_save_time", "a00003.html#acb9ffd5b9aeabae80e3c413e6ac1ecc2", null ],
    [ "r2w_gest_delay", "a00003.html#a4a7f00fcd69683f3b7d1ea218196fff4", null ],
    [ "r2w_mounting_matrix", "a00003.html#a1f2cef7ae0859c9c1e12de34e0f0c196", null ],
    [ "r2w_sleep_time_out", "a00003.html#a460a46bf688e5b569ed5e367e1de3da9", null ],
    [ "sensitivity_mode", "a00003.html#aabac64d18a4a3dfb0daba983469fd0e2", null ],
    [ "tilt_wait_time", "a00003.html#a9ad6eead705203915f321f014995e977", null ]
];